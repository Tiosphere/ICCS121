# a
git clone https://github.com/rausavar/MUIC-s2021-t3-syskill
git brand u6381360
git chechout u6381360
git remote add upstream https://github.com/rausavar/MUIC-s2021-t3-syskill

# b
egrep -Rn "myMalloc" ./assignmentX

# c
git checkout adbe182fe
git commit
git push origin main

# d
1. start with character 'a'
2. follow with any character
3. follow with 'b'
4. follow with 0 or more character

# e
^0?[1-9]+[.]?\d*|^0.\d+

# f
1. use cd .. to leave the home folder
2. use find ./ -maxdepth 3 -type f -name "*.txt" to find test file. Because we dont have many file so we can use this to find easily
3. use cat [path] to read the file
4. use vim [path] to add the key to file